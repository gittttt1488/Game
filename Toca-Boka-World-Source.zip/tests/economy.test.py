import sqlite3,json,pathlib
schema=next(pathlib.Path('drizzle').glob('0000_*.sql')).read_text()
db=sqlite3.connect(':memory:');db.executescript(schema)
db.execute("INSERT INTO users VALUES ('p','Player','player','active','{}',0,0,0)");db.execute("INSERT INTO wallets VALUES ('p',0)");db.execute("INSERT INTO player_inventory VALUES ('p','basic-brush',0)")
def balance():return db.execute('SELECT coins FROM wallets').fetchone()[0]
def tx(claim,kind,amount,item=None):
 db.execute('INSERT OR IGNORE INTO coin_transactions VALUES (?,?,?,?,?,?,?,?)',(claim,'p',claim,kind,amount,item,'p',0))
assert balance()==0
try:tx('poor','purchase',-100,'lipstick');raise AssertionError('Insufficient funds allowed')
except sqlite3.IntegrityError:pass
assert balance()==0
tx('level:jump:1','level',500);tx('level:jump:1','level',500);assert balance()==500
tx('purchase:lipstick','purchase',-100,'lipstick');assert balance()==400
try:tx('different-id','purchase',-100,'lipstick');raise AssertionError('Duplicate charged')
except sqlite3.IntegrityError:pass
assert balance()==400
for i in range(5):tx(f'failure:{i}','failure',-100)
assert balance()==0
tx('failure:4','failure',-100);assert balance()==0
for i,n in enumerate([150,350,400]):tx(f'preset:{i}','preset',n)
assert balance()==900
assert db.execute("SELECT count(*) FROM player_inventory WHERE item_id='lipstick'").fetchone()[0]==1
assert db.execute('SELECT count(*) FROM audit_logs').fetchone()[0]==10
print(json.dumps({'atomicWallet':'passed','duplicatePurchase':'blocked','duplicateReward':'blocked','failureOnce':'passed','zeroFloor':'passed','presetRewards':'passed','auditLog':'passed'}))
