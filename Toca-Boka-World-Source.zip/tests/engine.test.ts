import assert from 'node:assert/strict';
import {levelConfig,validateLevel,initialPhysics,physicsStep,replayPhysics,boardFor,evaluateMoves,rng} from '../lib/engine.ts';
import {items,scorePreset,presetReward,preset} from '../lib/catalog.ts';
const layouts=new Set<string>();let simulations=0;
for(let seed=1;seed<=1000;seed++){
 const c=levelConfig(seed);assert.ok(validateLevel(c));layouts.add(JSON.stringify(c.platforms));
 for(const level of [1,2,30,100]){
 const c=levelConfig(seed,level);assert.ok(validateLevel(c));let s=initialPhysics('jump');const inputs:number[][]=[];
 while(s.status==='playing'){
 const current=c.platforms.find(p=>s.x>=p.x-18&&s.x<=p.x+p.w+18);
 const jump=!!current&&s.ground&&s.x>=current.x+current.w-17&&s.x<c.finish-50;
 if(jump)inputs.push([s.frame+1,1]);s=physicsStep('jump',seed,level,s,jump);
 }
 assert.equal(s.status,'won',`Unreachable seed ${seed} level ${level}`);
 assert.equal(replayPhysics('jump',seed,level,inputs,s.frame).status,'won');simulations++;
 }
}
assert.equal(layouts.size,1000);assert.notDeepEqual(levelConfig(1,1).platforms,levelConfig(1,2).platforms);
let held=initialPhysics('jump');held=physicsStep('jump',1,1,held,true);const vy=held.vy;held=physicsStep('jump',1,1,held,true);assert.ok(held.vy>vy,'Airborne input cannot reset jump velocity');
for(let seed=1;seed<=1000;seed++){
 const b=boardFor('puzzle',seed);assert.deepEqual([...b].sort(),[0,1,2,3,4,5,6,7,8]);
 // A* solves every generated 8-puzzle, proving the scrambling is reversible.
 const start=b.join(''),goal='123456780';const queue:[string,number[]][]=[[start,[]]],seen=new Set([start]);let solved=false;
 while(queue.length){queue.sort((a,b)=>priority(a)-priority(b));const [key,moves]=queue.shift()!;if(key===goal){assert.equal(evaluateMoves('puzzle',seed,moves).won,true);solved=true;break;}const a=key.split(''),z=a.indexOf('0');for(const m of [z-3,z+3,z%3?z-1:-1,z%3<2?z+1:-1].filter(x=>x>=0&&x<9)){const next=[...a];[next[z],next[m]]=[next[m],next[z]];const k=next.join('');if(!seen.has(k)){seen.add(k);queue.push([k,[...moves,m]])}}}
 function priority([key,m]:[string,number[]]){return m.length+key.split('').reduce((n,x,i)=>x==='0'?n:n+Math.abs(Math.floor(i/3)-Math.floor((+x-1)/3))+Math.abs(i%3-(+x-1)%3),0)}
 assert.ok(solved);
 for(const game of ['color','dress','sorting']){const n=game==='color'?6:game==='dress'?4:9;assert.equal(evaluateMoves(game,seed,boardFor(game,seed).slice(0,n)).won,true)}
 const cards=boardFor('memory',seed),moves=[];for(let i=0;i<6;i++)moves.push(...cards.flatMap((v,n)=>v===i?[n]:[]));assert.equal(evaluateMoves('memory',seed,moves).won,true);
}
for(let seed=1;seed<=30;seed++)for(const game of ['fly','runner','catch']){let s=initialPhysics(game);const inputs:number[][]=[];const r=rng(seed),centers=Array.from({length:6},()=>135+r()*110);const rr=rng(seed),stars=Array.from({length:20},()=>30+rr()*540);while(s.status==='playing'){let press=false,target=s.x;if(game==='fly'){const index=Math.max(0,Math.min(5,Math.ceil((s.x-332)/210)));press=s.y>centers[index]&&s.vy>0;}if(game==='runner'){const obstacle=Array.from({length:8},(_,i)=>380+i*250+seed%41).find(x=>x>s.x-28);press=s.ground&&obstacle!==undefined&&obstacle-s.x<55;}if(game==='catch'){const i=Math.max(0,Math.floor((s.frame-110)/66));target=stars[i];}if(press||game==='catch')inputs.push([s.frame+1,game==='catch'?target:1]);s=physicsStep(game,seed,1,s,press,target);}assert.equal(s.status,'won',game+' seed '+seed);}
assert.equal(items.filter(i=>i.category==='Beauty Tools').length,25);assert.ok(items.filter(i=>i.category==='Beauty Tools'&&i.id!=='basic-brush').every(i=>i.price===100));assert.deepEqual([54,55,79,80,94,95,100].map(presetReward),[0,150,150,350,350,400,400]);
const p=preset(0,['basic-brush']),strokes=p.steps.map(s=>({...s,size:17,opacity:.7}));assert.equal(scorePreset(0,strokes,['basic-brush']),100);assert.equal(scorePreset(0,[],['basic-brush']),0);assert.equal(evaluateMoves('timing',1,[90,90,90]).won,true);
console.log(JSON.stringify({distinctLayouts:layouts.size,jumpSimulations:simulations,puzzlesSolved:1000,otherPhysicsWins:90,boardWinProofs:4000,economyCatalog:'passed',presetTiers:'passed',airborneSpam:'passed'}));
